package com.example.service_transactions.service;

import com.example.service_transactions.repository.TransactionRepository;
import org.example.entites.Transaction;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public Transaction creerTransaction(Transaction transaction) {
        transaction.setStatus("PENDING"); // Initial status
        transaction.setDate(java.time.LocalDateTime.now()); // Current date
        return transactionRepository.save(transaction);
    }

    public Transaction validerTransaction(Long id) {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction introuvable !"));
        transaction.setStatus("COMPLETED");
        return transactionRepository.save(transaction);
    }

    public List<Transaction> trouverParUtilisateurSource(Long utilisateurId) {
        return transactionRepository.findByDestinateurUtilisateurId(utilisateurId);
    }

    public List<Transaction> trouverParUtilisateurDestinataire(Long utilisateurId) {
        return transactionRepository.findByDestinataireUtilisateurId(utilisateurId);
    }
}
