package com.example.service_transactions.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SecurityConfig {

        @Bean
        public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
            http
                    .csrf().disable() // Désactive la protection CSRF
                    .authorizeRequests()
                    .antMatchers("/transactions/**").authenticated() // Protéger les endpoints commençant par /transactions/
                    .anyRequest().permitAll() // Permettre les autres endpoints
                    .and()
                    .httpBasic(); // Activer l'authentification HTTP Basic

            return http.build();
        }    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*");
            }
        };
    }

}
